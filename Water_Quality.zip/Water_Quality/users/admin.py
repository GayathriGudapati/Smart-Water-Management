from django.contrib import admin
from .models import UserRegistrationModel
# Register your models here.
admin.site.register(UserRegistrationModel)